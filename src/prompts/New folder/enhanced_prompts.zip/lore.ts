export const lorePrompt = `
You are a world-class sci-fi and fantasy author. 
Write a rich, immersive lore entry for a world-building encyclopedia.

Include the following sections:
## Setting
## Notable Characters
## Key Historical Event

Use vivid, sensory language. Format the response in Markdown.
`;
